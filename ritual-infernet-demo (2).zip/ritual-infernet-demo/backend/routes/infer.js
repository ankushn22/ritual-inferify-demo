// backend/routes/infer.js
const express = require('express');
const router = express.Router();
const axios = require('axios');
const crypto = require('crypto');
require('dotenv').config();

// POST /api/infer
// body: { prompt: string }
router.post('/', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: 'prompt required' });

    const inferUrl = process.env.RITUAL_INFER_URL;
    const apiKey = process.env.RITUAL_API_KEY;

    let modelOutput;

    if (inferUrl && apiKey && inferUrl !== 'REPLACE_WITH_YOUR_KEY' && apiKey !== 'REPLACE_WITH_YOUR_KEY') {
      // Try real Infernet call when config present
      try {
        const payload = { input: prompt }; // adapt payload shape as per Ritual docs if needed
        const inferResp = await axios.post(inferUrl, payload, {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 15000 // 15s timeout
        });

        // Use response from real API
        modelOutput = inferResp.data;
      } catch (err) {
        console.error('Real infer call failed, falling back to dummy response:', err?.response?.data || err.message);
        // fallback to dummy if real call fails
        modelOutput = {
          reply: `Demo fallback reply for prompt: "${prompt}"`,
          model: "ritual-demo-fallback",
          error: (err.response && err.response.data) ? err.response.data : undefined
        };
      }
    } else {
      // 🔥 Dummy response (no API key available) - good for demos and sharing
      modelOutput = {
        reply: `Demo reply for prompt: "${prompt}"`,
        model: "ritual-demo"
      };
    }

    // Compute provenance hash (sha256) of the model output
    const hash = crypto.createHash('sha256').update(JSON.stringify(modelOutput)).digest('hex');

    // TODO: If you get Ritual testnet RPC + private key, add on-chain write here.
    // Example (pseudocode):
    // const { ethers } = require('ethers');
    // const provider = new ethers.providers.JsonRpcProvider(process.env.RITUAL_TESTNET_RPC);
    // const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
    // const tx = await wallet.sendTransaction({ to: SOME_CONTRACT_OR_ADDRESS, data: encodeHashSomehow(hash) });
    // await tx.wait();

    return res.json({ ok: true, modelOutput, provenanceHash: hash });
  } catch (err) {
    console.error('infer route error:', err);
    return res.status(500).json({ error: 'infer call failed', details: err.message });
  }
});

module.exports = router;
