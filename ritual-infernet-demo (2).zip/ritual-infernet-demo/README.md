# Ritual Infernet Demo (MVP)

A minimal demo showing how a user can send a prompt, call Ritual's Infernet (inference) API, and display the result. 
This is designed as an MVP to show in the Ritual #i-build channel.

> NOTE: Replace RITUAL_INFER_URL and RITUAL_API_KEY in the backend .env with actual values from Ritual docs / team. 
The on-chain transaction submission is left as a simulated step.

## Run locally

### Backend
```
cd backend
cp .env.example .env
npm install
npm run dev
```

### Frontend
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173
